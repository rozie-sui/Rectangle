﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConShape
{
    internal class Program
    {
        static void Main(string[] args)
        {
            clsShape shape1 = new clsShape();
            shape1.Name = "Trapezoid";
            Console.WriteLine("Shape: " + shape1.Name);
            shape1.Sides = 4;
            Console.WriteLine("No. of Sides: " + shape1.Sides);
            Console.WriteLine("Area: " + shape1.ComputeArea());
            Console.WriteLine("Perimeter: " +shape1.ComputePerimeter());
            Console.WriteLine("");

            clsSquare sh2 = new clsSquare("Square", 4, 2);
            Console.WriteLine(sh2.ToString());
            Console.WriteLine("");


            clsRectangle sh3 = new clsRectangle("Rectangle", 4, 3);
            Console.WriteLine(sh3.ToString());
        }
    }
}

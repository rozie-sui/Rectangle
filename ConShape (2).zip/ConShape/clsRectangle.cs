﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConShape
{
    internal class clsRectangle : clsShape
    {
        private double length;
        private double width;


        public clsRectangle()
        {

        }

        public clsRectangle(string name, double length, double width)
        {
            base.Name = name;
            this.length = length;
            this.width = width;
        }

        public override string ToString()
        {
            return "Name: " + base.Name +
                "\n Area: " + this.ComputeArea() +
                "\n Perimeter: " + this.ComputePerimeter() +
                "\n Length: " + this.length +
                "\n Width: " + this.width;
        }

        public double Length { get => length; set => length = value; }
        public double Width { get => width; set => width = value; }

        public override double ComputeArea()
        {
            return length * width;
        }

        public override double ComputePerimeter()
        {
            return (length * 2) + (width * 2);
        }

    }
}
